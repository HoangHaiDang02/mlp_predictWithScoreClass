# import pandas as pd
# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import LabelEncoder, StandardScaler
# from keras.models import Sequential
# from keras.layers import Dense
#
# # Đọc dữ liệu từ tệp CSV
# data = pd.read_csv("./thpt.csv")
#
# # Chuyển đổi nhãn sang dạng số
# label_encoder = LabelEncoder()
# data['label'] = label_encoder.fit_transform(data['label'])
#
# # Tách đặc trưng và nhãn
# X = data.iloc[:, :-1]
# y = data['label']
#
# # Chia dữ liệu thành tập huấn luyện và tập kiểm tra
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)
#
# # Chuẩn hóa dữ liệu
# # scaler = StandardScaler()
# # X_train = scaler.fit_transform(X_train)
# # X_test = scaler.transform(X_test)
# scaler = StandardScaler()
# X_train.loc[:, :'Anh'] = scaler.fit_transform(X_train.loc[:, :'Anh'])
# X_test.loc[:, :'Anh'] = scaler.transform(X_test.loc[:, :'Anh'])
#
# # Xây dựng mô hình nơ-ron
# model = Sequential()
# model.add(Dense(100, input_dim=15, activation='relu'))
# model.add(Dense(50, activation='relu'))
# model.add(Dense(6, activation='softmax'))
#
# # Huấn luyện mô hình
# model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# model.fit(X_train, y_train, epochs=100, batch_size=32, validation_data=(X_test, y_test))
#
# # Dự đoán
# def predict_grade(scores):
#     transformed_scores = scaler.transform([scores])
#     prediction = model.predict_classes(transformed_scores)
#     return prediction[0]
#
# # Nhập dữ liệu và dự đoán
# toan = float(input("Nhập điểm toán : "))
# ly = float(input("Nhập điểm lý: "))
# hoa = float(input("Nhập điểm hoá: "))
# sinh = float(input("Nhập điểm sinh : "))
# van = float(input("Nhập điểm văn: "))
# su = float(input("Nhập điểm sử : "))
# dia = float(input("Nhập điểm địa: "))
# anh = float(input("Nhập điểm anh: "))
#
# # predicted_grade = predict_grade([toan, ly, hoa, sinh, van, su, dia, anh])
# predictions = model.predict(transformed_scores)
# predicted_class = predictions.argmax(axis=-1)
# predicted_grade = label_encoder.inverse_transform(predicted_class)[0]
#
#
# # Chuyển nhãn trở lại dạng chữ
# def result_predict(predict):
#     result = ''
#     if predict==0:
#         result = 'A00'
#     elif predict==1:
#         result = 'A01'
#     elif predict==2:
#         result = 'B00'
#     elif predict==3:
#         result = 'B08'
#     elif predict==4:
#         result = 'C00'
#     else:
#         result = 'D00'
#     return result
#
# # In kết quả dự đoán
# print("Dự đoán kết quả: ", result_predict(predicted_grade))
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Dense

# Đọc dữ liệu từ tệp CSV
data = pd.read_csv("./thpt.csv")

# Chuyển đổi nhãn sang dạng số
label_encoder = LabelEncoder()
data['label'] = label_encoder.fit_transform(data['label'])

# Tách đặc trưng và nhãn
# X = data.iloc[:, :-1]
# y = data['label']
X = data.iloc[:, :9]
y = data.iloc[:, -7:] # Lấy 7 cột cuối cùng làm nhãn

# Chia dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Xây dựng mô hình nơ-ron
# model = Sequential()
# model.add(Dense(100, input_dim=15, activation='relu'))
# model.add(Dense(50, activation='relu'))
# model.add(Dense(6, activation='softmax'))

model = Sequential()
model.add(Dense(100, input_dim=9, activation='relu'))
model.add(Dense(50, activation='relu'))
model.add(Dense(7, activation='softmax'))

# Huấn luyện mô hình
# model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# model.fit(X_train, y_train, epochs=100, batch_size=32, validation_data=(X_test, y_test))
model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X_train, y_train, epochs=100, batch_size=32, validation_data=(X_test, y_test))

# Dự đoán
# def predict_grade(scores):
#     prediction = model.predict_classes(scores)
#     return prediction[0]
def predict_grade(scores):
    # score_array = [score if str(score) != '' else 0 for score in scores]
    # score_array = label_encoder.transform(score_array).reshape(1, -1)
    # prediction = model.predict_classes(score_array)
    # return prediction[0]
    score_array = [score if str(score) != '' else 0 for score in scores]
    score_array = label_encoder.transform(score_array).reshape(1, -1)
    prediction = model.predict_classes(score_array)
    return prediction[0]

# Nhập dữ liệu và dự đoán
toan = float(input("Nhập điểm toán : "))
ly = float(input("Nhập điểm lý: "))
hoa = float(input("Nhập điểm hoá: "))
sinh = float(input("Nhập điểm sinh : "))
van = float(input("Nhập điểm văn: "))
su = float(input("Nhập điểm sử : "))
dia = float(input("Nhập điểm địa: "))
anh = float(input("Nhập điểm anh: "))

# Chuẩn hóa dữ liệu đầu vào
# score_array = [toan, ly, hoa, sinh, van, su, dia, anh]
# score_array = label_encoder.transform([''] + score_array)[1:]
# score_array = score_array.reshape(1, -1)
# Chuẩn hóa dữ liệu đầu vào
# Chuẩn hóa dữ liệu đầu vào
# Chuẩn hóa dữ liệu đầu vào
# Chuẩn hóa dữ liệu đầu vào
score_array = [toan, ly, hoa, sinh, van, su, dia, anh]
for i in range(len(score_array)):
    if score_array[i] not in label_encoder.classes_:
        # Tìm giá trị gần nhất trong tập giá trị đã sử dụng để huấn luyện mô hình
        # similar_value = label_encoder.classes_[np.argmin(np.abs(label_encoder.classes_ - score_array[i]))]
        similar_value = label_encoder.classes_[np.abs(label_encoder.classes_ - score_array[i]).argmin()]
        score_array[i] = similar_value

score_array = label_encoder.transform(score_array).reshape(1, -1)
prediction = model.predict_classes(score_array)
predicted_grade = label_encoder.inverse_transform([prediction])[0]

# Dự đoán và giải mã nhãn dự đoán
# predicted_grade = predict_grade(score_array)
# predicted_grade = label_encoder.inverse_transform([predicted_grade])[0]

# Chuyển nhãn trở lại dạng chữ
def result_predict(predict):
    result = ''
    if predict==0:
        result = 'A00'
    elif predict==1:
        result = 'A01'
    elif predict==2:
        result = 'B00'
    elif predict==3:
        result = 'B08'
    elif predict==4:
        result = 'C00'
    else:
        result = 'D00'
    return result

# In kết quả dự đoán
print("Dự đoán kết quả: ", result_predict(predicted_grade))
